#include <iostream>
#include "ObjectCounter.hpp"

using namespace std;

int main(){
	ObjectCounter ob1;
	ObjectCounter ob2;
	cout << ob1.getCount() << endl;
	return 0;
}
