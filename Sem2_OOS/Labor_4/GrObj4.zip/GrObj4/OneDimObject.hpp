#pragma once
#include "DrawingObject.hpp"

class OneDimObject : public DrawingObject
{
	public: 
		OneDimObject();
		~OneDimObject();
};
