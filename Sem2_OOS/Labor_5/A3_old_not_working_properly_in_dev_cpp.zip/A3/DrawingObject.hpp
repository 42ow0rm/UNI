#include "MyData.hpp"
#pragma once

class DrawingObject : public MyData
{
};