#pragma once
#include "DrawingObject.hpp"

DrawingObject::GraphException::GraphException(const unsigned int i): id(i) {}
