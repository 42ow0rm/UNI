// main.cpp zur Demonstration der vorhersehbaren Fehler
#include <iostream>
#include "DrawingObject.hpp"
#include "Polygonline.hpp"
using namespace std;
bool debugConstructor = false;
unsigned int ObjectCounter::maxId = 0;
unsigned int ObjectCounter::number = 0;
int main() {
	try{
	// Punkt erstellen und Infos ausgeben
	const Point p;
	cout << "maxId = " << ObjectCounter::getMaxId() << endl;
	cout << "ID von p = " << p.getId() << endl;
	// ID von p unerlaubt �ndern
	*(((int*)(&p))+1) = ObjectCounter::getMaxId() + 10;
	p.check();
	// Punkt ausgeben
	cout << "ID von p = " << p.getId() << endl;
	p.print();
	}

		catch (DrawingObject::IdTooHigh & e){
		cout << "Fehler: Die Id wurde unerlaubt auf " << e.getId() << " veraendert!" << endl;
	}

		catch (DrawingObject::GraphException & e){
		cout << "Fehler aufgetreten!" << endl;
	}

	try {
	// Polygonline erstellen und ausgeben
	Polygonline pl;
	pl.addPoint(Point(1, 1));
	pl.addPoint(Point(2, 2));
	pl.addPoint(Point(3, 3));
	pl.addPoint(Point(4, 4));
	pl.print();
	// Polygonline unerlaubt �ndern
	PlgElement * first = (PlgElement *)(*((int*)(&pl) + 1)); //
    PlgElement * last = (PlgElement *)(*((int*)(&pl) + 2)); //
	last->setNext(first);
	// Polygonline ausgeben
	pl.print();
	}

	catch (Polygonline::LoopInLine & l){
		cout << "Fehler: Loop in Polygonline mit der Id: " << l.getId() << endl;
	}

	catch (DrawingObject::GraphException & e){
		cout << "Fehler aufgetreten!" << endl;
	}

	return 0;
}