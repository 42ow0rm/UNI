#pragma once 
#include "DrawingObject.hpp"

class OneDimObject: public DrawingObject {
public:
	//Konstruktor
	OneDimObject();

	//Destruktor
	~OneDimObject();

};