#pragma once
#include "Circle.hpp"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

bool debugConstructor = false;
unsigned int ObjectCounter::maxId=0;
unsigned int ObjectCounter::number=0;

int main(void){
	Point p;
	int  k = 0;
	Circle ** kreis;
	Circle * ptr;
	ifstream datei("kreis.dat",ios::binary); //Datei bin�r zum lesen �ffnen
	if(!datei)
		cerr << "Datei konnte nicht geoeffnet werden!" << endl;

	datei.read(reinterpret_cast<char*>(&k), sizeof(int)); //Anzahl der objekte aus der datei lesen
	kreis = new Circle * [k]; //Dynamisches Array mit der entsprechenden gr��e erstellen

	for(int i = 0;i<k;i++){
		ptr = new Circle(p);	//Speicherplatz von heap anfordern
		datei.read(reinterpret_cast<char*>(ptr),sizeof(Circle)); //Kreis-Objekt aus der Datei lesen
		kreis[i] = new Circle(ptr->toString());
		kreis[i]->print();
	}

	datei.close(); //Datei schlie�en
	delete [] kreis;
	return 0;
}
